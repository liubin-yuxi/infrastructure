mkdir -p /data/db
mkdir -p /data/logs
touch /data/logs/mongo.log